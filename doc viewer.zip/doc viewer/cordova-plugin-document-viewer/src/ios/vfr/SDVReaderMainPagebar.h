//
//  SDVReaderMainPagebar.h
//
//  override page number to language neutral default
//
//  Created by Philipp Bohnenstengel on 04.11.14.
//
//

#import "ReaderMainPagebar.h"

@interface SDVReaderMainPagebar : ReaderMainPagebar

@end
